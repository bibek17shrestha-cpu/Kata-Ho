Drop your logo.png here — index.html already references it at assets/logo.png.
